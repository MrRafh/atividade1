package com.example.denguechikungunya.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.time.Period;

@Controller
public class NotificacaoController {


    @RequestMapping("/notificar")
    public String exibirFormulario() {
        return "notificar"; 
    }

    @PostMapping("/notificar")
    public String processarNotificacao(
            @RequestParam("doenca") String doenca,
            @RequestParam("dataNotificacao") String dataNotificacao,
            @RequestParam("unidadeSaude") String unidadeSaude,
            @RequestParam("municipioNotificacao") String municipioNotificacao,
            @RequestParam("uf") String uf,
            @RequestParam("dataNascimento") String dataNascimento,
            @RequestParam("nomeMae") String nomeMae,
            @RequestParam("idade") String idade,
            @RequestParam("sexo") String sexo,
            @RequestParam("municipioResidencia") String municipioResidencia,
            @RequestParam("ufResidencia") String ufResidencia,
            Model model) {

        if (!dataNascimento.isEmpty()) {
            LocalDate dataNasc = LocalDate.parse(dataNascimento);
            int calculoIdade = Period.between(dataNasc, LocalDate.now()).getYears();
            model.addAttribute("idade", calculoIdade);
        }

        System.out.println("Doença: " + doenca);
        System.out.println("Data da Notificação: " + dataNotificacao);
        System.out.println("Unidade de Saúde: " + unidadeSaude);
        System.out.println("Município de Notificação: " + municipioNotificacao);
        System.out.println("UF: " + uf);
        System.out.println("Data de Nascimento: " + dataNascimento);
        System.out.println("Nome da Mãe: " + nomeMae);
        System.out.println("Idade: " + idade);
        System.out.println("Sexo: " + sexo);
        System.out.println("Município de Residência: " + municipioResidencia);
        System.out.println("UF de Residência: " + ufResidencia);

        return "redirect:/"; 
    }
}
