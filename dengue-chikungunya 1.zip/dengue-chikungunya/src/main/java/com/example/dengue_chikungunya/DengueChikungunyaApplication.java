package com.example.dengue_chikungunya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DengueChikungunyaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DengueChikungunyaApplication.class, args);
	}

}
